<!DOCTYPE html>
<html>
    <head>
        <title>Daftar Akun</title>
        <link rel="stylesheet" href="./style.css">
    </head>
    <body>
        <div style="background-color: #FFFFFF6B;width: 50%;margin: auto;padding: 5px; border-radius: 10px; font-family: open sans-serif;">
        <h1 style="text-align: center;">Sign Up Account</h1>
        <form action="form_aksi.php" method="POST">
            <table style="margin: auto;">
            <tr>
                    <td>Username</td>
                    <td> : </td>
                    <td><input type="username" name="username" placeholder="Masukan Username"></td>
                </tr>
                <tr>
                    <td>Password</td>
                    <td> : </td>
                    <td><input type="password" name="pasword" placeholder="Masukan Password"></td>
                </tr>
                <tr>
                    <td>Nama Lengkap</td>
                    <td> : </td>
                    <td><input type="text" name="nama" placeholder="Masukan Nama Lengkap"></td>
                </tr>
                <tr>
                    <td>Email</td>
                    <td> : </td>
                    <td><input type="email" name="email" placeholder="Masukan Email"></td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td>
                        <button type="submit" name="kirim">Kirim</button>
                        <button type="reset" name="reset">Batal</button>
                    </td>
                </tr>
                
            </table>
            <div class="flex-col-c p-t-155">
                    <a href="../index_login.php" class="txt2">
							Login
					</a>
					</div>
            </form>
    </body>
</html>