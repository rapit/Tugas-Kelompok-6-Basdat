
<!DOCTYPE html>
<html>
    <head>
        <body>
        <title>Certificate</title>
        <tr>
        <img src="../images/certificate.jpg" class="img-fluid" alt="">
        <button><a href="../admin/index_hal_utama.php" class="txt2">
							Back to home
						</a></button>
        </tr>
        </body>
    </head>
</html>
