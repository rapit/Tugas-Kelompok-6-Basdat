
<?php
$conn = mysqli_connect("localhost","root","","TugasAkhir");
$Babakan = $conn->query("select * from kelurahan where kelurahan='Babakan'");
$jml_Babakan = $Babakan->num_rows;

$Ciherang = $conn->query("select * from kelurahan where kelurahan='Ciherang'");
$jml_Ciherang = $Ciherang->num_rows;

$Cikarawang = $conn->query("select * from kelurahan where kelurahan='Cikarawang'");
$jml_Cikarawang = $Cikarawang->num_rows;

$Dramaga = $conn->query("select * from kelurahan where kelurahan='Dramaga'");
$jml_Dramaga = $Dramaga->num_rows;

$Neglasari = $conn->query("select * from kelurahan where kelurahan='Neglasari'");
$jml_Neglasari = $Neglasari->num_rows;

$Petir = $conn->query("select * from kelurahan where kelurahan='Petir'");
$jml_Petir = $Petir->num_rows;

$Purwasari = $conn->query("select * from kelurahan where kelurahan='Purwasari'");
$jml_Purwasari = $Purwasari->num_rows;

$Sinar_Sari = $conn->query("select * from kelurahan where kelurahan='Sinar Sari'");
$jml_Sinar_Sari = $Sinar_Sari->num_rows;

$Sukadamai = $conn->query("select * from kelurahan where kelurahan='Sukadamai'");
$jml_Sukadamai = $Sukadamai ->num_rows;

$Sukawening = $conn->query("select * from kelurahan where kelurahan='Sukawening'");
$jml_Sukawening = $Sukawening->num_rows;

?>
<html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Task', 'Banyak Orang'],
          ['Babakan',     <?php echo $jml_Babakan ?>],
          ['Ciherang',     <?php echo $jml_Ciherang ?>],
          ['Cikarawang', <?php echo $jml_Cikarawang ?>],
          ['Dramaga', <?php echo $jml_Dramaga ?>],
          ['Neglasari',   <?php echo $jml_Neglasari ?>],
          ['Petir',  <?php echo $jml_Petir ?>],
          ['Purwasari',    <?php echo $jml_Purwasari ?>],
          ['Sinar Sari',     <?php echo $jml_Sinar_Sari ?>],
          ['Sukadamai',  <?php echo $jml_Sukadamai ?>],
          ['Sukawening', <?php echo $jml_Sukawening ?>]
        ]);

        var options = {
          title: 'JUMLAH DATA PASIEN VAKSIN - KELURAHAN',
          is3D: true,
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart_3d'));
        chart.draw(data, options);
      }
    </script>
  </head>
  <body style="background-color: darkturquoise;">
    <div id="piechart_3d" style="width: 900px; height: 500px;"></div>
    <tr>
                    <td></td>
                    <td><a href="../index_hal_utama.php" > HOME </a></td> </br>
                    <td>
                        <a href="./data_vaksin3.php" >JUMLAH DATA PASIEN VAKSIN - JENIS VAKSIN</a>
                    </td>
                </tr>

  </body>
</html>

