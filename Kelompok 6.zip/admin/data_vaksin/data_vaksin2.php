
<?php
$conn = mysqli_connect("localhost","root","","TugasAkhir");
$Manggis = $conn->query("select * from lokasi where tempat_vaksin='Puskesmas KP. Manggis'");
$jml_Manggis = $Manggis->num_rows;

$Cangku = $conn->query("select * from lokasi where tempat_vaksin='Puskesmas Cangkurawok'");
$jml_Cangku = $Cangku->num_rows;

$Dramaga = $conn->query("select * from lokasi where tempat_vaksin='Puskesmas Dramaga'");
$jml_Dramaga = $Dramaga->num_rows;

$IPB = $conn->query("select * from lokasi where tempat_vaksin='Poliklinik IPB'");
$jml_IPB = $IPB->num_rows;
?>
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script type="text/javascript">
    google.charts.load("current", {
        packages: ['corechart']
    });
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {
        var data = google.visualization.arrayToDataTable([
            ["Element", "Density", {
                role: "style"
            }],
            ["Puskesmas KP. Manggis",<?php echo $jml_Manggis ?>, "#b87333"],
            ["Puskesmas Cangkurawok", <?php echo $jml_Cangku ?>, "silver"],
            ["Puskesmas Dramaga",<?php echo $jml_Dramaga ?>, "gold"],
            ["Poliklinik IPB",<?php echo $jml_IPB ?>, "red"]
        ]);

        var view = new google.visualization.DataView(data);
        view.setColumns([0, 1,
            {
                calc: "stringify",
                sourceColumn: 1,
                type: "string",
                role: "annotation"
            },
            2
        ]);

        var options = {
            title: "JUMLAH DATA PASIEN VAKSIN - TEMPAT VAKSIN",
            width: 600,
            height: 400,
            bar: {
                groupWidth: "95%"
            },
            legend: {
                position: "none"
            },
        };
        var chart = new google.visualization.ColumnChart(document.getElementById("columnchart_values"));
        chart.draw(view, options);
    }
</script>
<body style="background-color: darkturquoise;"></body>
<div id="columnchart_values" style="width: 900px; height: 300px;"></div>
<html>
    <head>

    <tr>
                    <td></td><br></br><br></br><br></br><br></br>
                    <td><a href="./data_vaksin3.php" >JUMLAH DATA PASIEN VAKSIN - JENIS VAKSIN </a></td> </br>
                    <td>
                        <a href="./data_vaksin4.php" >JUMLAH DATA PASIEN VAKSIN - DOKTER</a>
                    </td>
                </tr>
        </body>
    </head>
</html>
