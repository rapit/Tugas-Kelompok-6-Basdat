
<?php
$conn = mysqli_connect("localhost","root","","TugasAkhir");
$Rafif = $conn->query("select * from dokter_vaksin where dokter='dr. Rafif Idul Fitra Sp.PA'");
$jml_Rafif = $Rafif->num_rows;

$Sultan = $conn->query("select * from dokter_vaksin where dokter='dr. Nur Sulthan Sp.PA'");
$jml_Sultan = $Sultan->num_rows;

$Jenny = $conn->query("select * from dokter_vaksin where dokter='dr. Riana Jeany Sp.PA'");
$jml_Jenny = $Jenny->num_rows;

$Rizky = $conn->query("select * from dokter_vaksin where dokter='dr. Muhammad Rizki A. Sp.PA'");
$jml_Rizky = $Rizky->num_rows;


?>
<html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Task', 'Banyak Orang'],
          ['dr. Muhammad Rizki A. Sp.PA',     <?php echo $jml_Rizky ?>],
          ['dr. Nur Sulthan Sp.PA',     <?php echo $jml_Sultan ?>],
          ['dr. Rafif Idul Fitra Sp.PA', <?php echo $jml_Rafif ?>],
          ['dr. Riana Jeany Sp.PA', <?php echo $jml_Jenny ?>]
        ]);

        var options = {
          title: 'JUMLAH DATA PASIEN VAKSIN - DOKTER',
          is3D: true,
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart_3d'));
        chart.draw(data, options);
      }
    </script>
  </head>
  <body  style="background-color: darkturquoise;">
    <div id="piechart_3d" style="width: 900px; height: 500px;" ></div>

  </body>
</html>
<tr>
                    <td></td>
                    <td>     <a href="../index_hal_utama.php" > HOME </a></td> </br>
                    <td>
                        <a href="./data_vaksin2.php" > JUMLAH DATA PASIEN VAKSIN - TEMPAT VAKSIN</a>
                    </td>
                </tr>

