<?php include("header.php") ?>
<!-- untuk mencari yang mau dicari -->
<?php
$sukses = "";
$katakunci = (isset($_GET['katakunci'])) ? $_GET['katakunci'] : "";
if (isset($_GET['op'])) {
    $op = $_GET['op'];
} else {
    $op = "";
}
if ($op == 'delete') {
    $id_login = $_GET['id_login'];
    $sql1   = "delete from login where id_login = '$id_login'";
    $q1     = mysqli_query($conn, $sql1);
    if ($q1) {
        $sukses     = "Berhasil hapus data";
    }
}
?>
<h3>Halaman Admin Vaksin</h3>
<?php
if ($sukses) {
?>
    <div class="alert alert-primary" role="alert">
        <?php echo $sukses ?>
    </div>
<?php
}
?>
<form class="row g-3" method="get">
    <div class="col-auto">
        <input type="text" class="form-control" placeholder="Masukkan Kata Kunci" name="katakunci" value="<?php echo $katakunci ?>" />
    </div>
    <div class="col-auto">
        <input type="submit" name"cari" value="Cari Tulisan" class="btn btn-secondary" />
    </div>
</form>
<!-- menyiapkan tabel untuk menampilkan data -->
<table class="table table-striped">
    <thead>
        <tr>
            <th class="col-1">#</th>
            <th>Username</th>
            <th>Password</th>
            <th>Nama Lengkap</th>
            <th>Email</th>
            <th class="col-1">Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $sqltambahan    = "";
        if ($katakunci != '') {
            $array_katakunci = explode(" ", $katakunci);
            for ($x = 0; $x < count($array_katakunci); $x++) {
                $sqlcari[] = "(username like '%" . $array_katakunci[$x] . "%' or pasword like '%" . $array_katakunci[$x] . "%' or nama like '%" . $array_katakunci[$x] . "%' or email like '%" . $array_katakunci[$x] . "%' )";
            }
            $sqltambahan    = " where " . implode(" or ", $sqlcari);
        }
        $sql1   = "select * from login $sqltambahan";
        $page   = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $q1     = mysqli_query($conn, $sql1);
        $nomor  = 1;


        $q1     = mysqli_query($conn, $sql1);
        while ($r1 = mysqli_fetch_array($q1)) {
        ?>
            <tr>
                <td><?php echo $nomor++ ?></td>
                <td><?php echo $r1['username'] ?></td>
                <td><?php echo $r1['pasword'] ?></td>
                <td><?php echo $r1['nama'] ?></td>
                <td><?php echo $r1['email'] ?></td>
                <td>
                    <a href="#?op=edit&id_login=<?php echo $r1['id_login'] ?>" onclick="return confirm('Apakah yakin mau edit data?')">
                        <span class="badge bg-danger">Edit</span>
                    </a>
                    <a href="./admin.php?op=delete&id_login=<?php echo $r1['id_login'] ?>" onclick="return confirm('Apakah yakin mau hapus data?')">
                        <span class="badge bg-danger">Delete</span>
                    </a>
                </td>
            </tr>
        <?php
        }
        ?>

    </tbody>
</table>
<nav aria-label="Page navigation example">
    <ul class="pagination">
        <?php 
        $cari = isset($_GET['cari'])? $_GET['cari'] : "";

            ?>

        ?>
    </ul>
</nav>
<?php include("footer.php") ?>