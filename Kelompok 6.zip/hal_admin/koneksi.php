<?php
$conn = mysqli_connect("localhost","root","","TugasAkhir");

if( !$conn)
{
    echo"Gagal";
}
else
{
    echo"Berhasil";
}
?>